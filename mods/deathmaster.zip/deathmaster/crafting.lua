--
-- Grave
--

minetest.register_craft({
	output = "deathmaster:grave",
	recipe = {
		{"", "default:stone", ""},
		{"", "default:stone", ""},
		{"default:stone", "default:stone", "default:stone"}
	}
})